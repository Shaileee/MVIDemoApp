package com.shaileedemo.mvimovies.presentation

class ViewPosterDetailStateHolderTest {

//    @get:Rule
//    var instantTaskExecutorRule = InstantTaskExecutorRule()
//    private val dataGateway = mockk<DataGateway>()
//    private val seeMovieDetail = SeeMovieDetail(dataGateway)
//    private val manageFavoriteMovie = ManageFavoriteMovie(dataGateway)
//    private val mapper = ViewMovieInfoMapper()
//    private val viewModel = MovieDetailViewModel(
//        seeMovieDetail = seeMovieDetail,
//        manageFavoriteMovie = manageFavoriteMovie,
//        mapper = mapper
//    )
//
//    @Test
//    fun `getLiveData not null`() {
//        assertNotNull(viewModel.uiState())
//    }
}
