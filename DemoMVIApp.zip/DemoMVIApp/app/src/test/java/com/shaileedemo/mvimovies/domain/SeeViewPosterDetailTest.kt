package com.shaileedemo.mvimovies.domain

class SeeViewPosterDetailTest {

//    private val dataGateway = mockk<DataGateway>()
//    private val useCase = SeeMovieDetail(dataGateway)
//
//    @Test
//    fun `given DomainMovieDetail, when getMovieDetailById, then return data`() = runBlocking {
//        val domainMovieDetail = makeDomainMovieDetail()
//        stubRepositoryGetMovieDetailById(domainMovieDetail)
//
//        val resultFlow = useCase.getMovieDetailById(RandomFactory.generateString())
//
//        resultFlow.collect {
//            assertEquals(domainMovieDetail, it)
//        }
//    }
//
//    private fun stubRepositoryGetMovieDetailById(domainMovieDetail: DomainMovieDetail) {
//        coEvery {
//            dataGateway.getMovieDetailById(RandomFactory.generateString())
//        } returns flow { emit(domainMovieDetail) }
//    }
}
