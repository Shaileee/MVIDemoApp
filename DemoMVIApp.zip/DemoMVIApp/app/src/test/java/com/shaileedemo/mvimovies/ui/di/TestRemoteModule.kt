package com.shaileedemo.mvimovies.ui.di

import dagger.Module

@Module
object TestRemoteModule {

//    @Provides
//    @JvmStatic
//    fun providesMovieRestApi(): WebServiceRetrofit {
//        return mockk()
//    }
//
//    @Provides
//    @JvmStatic
//    fun providesMoviesRemote(): Remote {
//        return mockk()
//    }
}
