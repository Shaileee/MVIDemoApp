package com.shaileedemo.mvimovies.ui.di

// @Module
object TestCacheModule {

//    @Provides
//    @JvmStatic
//    fun providesDatabase(application: Application): CacheDatabase {
//        return CacheDatabase.getInstance(application)
//    }
//
//    @Provides
//    @JvmStatic
//    fun providesMovieCache(): MovieCache {
//        return mock()
//    }
}
