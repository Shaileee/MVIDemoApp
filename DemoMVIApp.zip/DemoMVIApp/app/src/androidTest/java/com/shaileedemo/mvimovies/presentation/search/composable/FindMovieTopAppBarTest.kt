package com.shaileedemo.mvimovies.presentation.search.composable

import androidx.compose.ui.test.junit4.createComposeRule
import org.junit.Rule

class FindMovieTopAppBarTest {
    @get:Rule
    val rule = createComposeRule()


}