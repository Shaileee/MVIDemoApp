package com.shaileedemo.mvimovies.network.model

internal object Constants {
    const val TITLE = "Title"
    const val YEAR = "Year"
    const val IMDBID = "imdbID"
    const val TYPE = "Type"
    const val POSTER = "Poster"
}
