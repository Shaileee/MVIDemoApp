package com.shaileedemo.mvimovies.domain.entities

class Language {

}