package com.shaileedemo.mvimovies.ui.favoriteMovies

//import androidx.recyclerview.widget.RecyclerView
//import com.bumptech.glide.Glide
//import com.shaileedemo.mvimovies.databinding.ItemFavoriteMovieBinding
//import com.shaileedemo.mvimovies.presentation.model.UiFavoriteMovie
//
//class FavoriteMoviesViewHolder(
//    private val binding: ItemFavoriteMovieBinding
//) : RecyclerView.ViewHolder(binding.root) {
//
//    fun bind(item: UiFavoriteMovie) {
//        binding.apply {
//            favoriteMovie = item
//            executePendingBindings()
//        }
//    }
//
//    fun setImage(poster: String?) {
//        Glide.with(binding.root)
//            .load(poster)
//            .into(binding.acivMovieAvatar)
//    }
//}
