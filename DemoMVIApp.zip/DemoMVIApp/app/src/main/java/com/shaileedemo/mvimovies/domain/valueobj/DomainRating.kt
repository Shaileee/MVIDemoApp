package com.tzion.jetpackmovies.domain.valueobj

data class DomainRating(
    val source: String?,
    val value: String?
)
