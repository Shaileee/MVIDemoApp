package com.shaileedemo.mvimovies.presentation.favorites

interface UserIntent {
    suspend fun execute()
}