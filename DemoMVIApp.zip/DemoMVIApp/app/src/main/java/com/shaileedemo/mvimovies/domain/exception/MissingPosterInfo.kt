packagecom.shaileedemo.mvimovies.domain.exception

class MissingPosterInfo : Exception()
