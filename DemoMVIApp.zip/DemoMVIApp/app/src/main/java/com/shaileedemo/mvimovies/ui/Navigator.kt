package com.shaileedemo.mvimovies.ui

//import android.view.View
//import androidx.navigation.findNavController
//import com.shaileedemo.mvimovies.ui.findMovies.FindMoviesByNameFragmentDirections
//import javax.inject.Inject
//
//class Navigator @Inject constructor() {
//
//    fun openMovieDetails(view: View?, movieId: String) {
//        val action = FindMoviesByNameFragmentDirections.actionFindMoviesByNameToMovieDetail(movieId)
//        view?.findNavController()?.navigate(action)
//    }

//    fun openMovieDetails(view: View?, favoriteMovie: UiFavoriteMovie) {
//        val action = FindMoviesByNameFragmentDirections.actionFindMoviesByNameToMovieDetail(movieId)
//        view?.findNavController()?.navigate(action)
//    }
//}
