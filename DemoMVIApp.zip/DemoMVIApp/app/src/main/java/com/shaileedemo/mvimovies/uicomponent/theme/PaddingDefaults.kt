package com.shaileedemo.mvimovies.uicomponent.theme

import androidx.compose.ui.unit.dp

object PaddingDefaults {
    val HorizontalTemplateContent = 16.dp
    val VerticalTemplateContent = 16.dp
}