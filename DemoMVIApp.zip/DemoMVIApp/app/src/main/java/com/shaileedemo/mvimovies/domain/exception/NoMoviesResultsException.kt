package com.shaileedemo.mvimovies.domain.exception

class NoMoviesResultsException(errorMsg: String) : Exception(errorMsg)
